const swiper = new Swiper('.swiper', {
  

  
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
  
    direction: "vertical",
    slidesPerView: 1,
    spaceBetween: 30,
    mousewheel: true,
  });